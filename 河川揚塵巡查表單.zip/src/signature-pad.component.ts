import { Component, AfterViewInit, ViewChild, ElementRef, output, ChangeDetectionStrategy, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-signature-pad',
  standalone: true,
  template: `
    <div class="w-full max-w-sm border border-gray-300 rounded-md p-2 space-y-2 shadow-sm bg-white">
      <canvas #canvas class="w-full h-40 bg-gray-50 rounded-md cursor-crosshair"></canvas>
      <div class="flex justify-end">
        <button type="button" (click)="clear()" class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
          清除
        </button>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SignaturePadComponent implements AfterViewInit, OnDestroy {
  @ViewChild('canvas') canvasEl!: ElementRef<HTMLCanvasElement>;
  signatureChange = output<string>();

  private signaturePad: any;
  private resizeHandler = () => this.handleResize();

  ngAfterViewInit() {
    // Use setTimeout to ensure the canvas has its final dimensions after
    // the browser has completed layout and paint cycles. This prevents a race
    // condition where offsetWidth could be 0 during initialization.
    setTimeout(async () => {
        try {
            const canvas = this.canvasEl.nativeElement;

            // It's crucial to set the canvas size before initializing the library
            const ratio = Math.max(window.devicePixelRatio || 1, 1);
            canvas.width = canvas.offsetWidth * ratio;
            canvas.height = canvas.offsetHeight * ratio;
            canvas.getContext('2d')?.scale(ratio, ratio);

            const signaturePadModule = await import('signature_pad');
            const SignaturePad = signaturePadModule.default;

            this.signaturePad = new SignaturePad(canvas, {
                backgroundColor: 'rgb(249, 250, 251)', // Corresponds to Tailwind's bg-gray-50
            });
            
            // FIX: The `onEnd` callback must be set on the instance, not passed in the constructor options,
            // according to the type definitions for the version of `signature_pad` being used.
            this.signaturePad.onEnd = () => {
                this.emitSignature();
            };

            window.addEventListener('resize', this.resizeHandler);
        } catch (error) {
            console.error('Failed to load or initialize SignaturePad', error);
            alert('簽名版元件載入失敗，請檢查網路連線並重新整理。');
        }
    }, 50);
  }
  
  ngOnDestroy() {
    window.removeEventListener('resize', this.resizeHandler);
    if (this.signaturePad) {
      this.signaturePad.off();
    }
  }

  private handleResize() {
    if (!this.canvasEl || !this.signaturePad) {
      return;
    }
    const canvas = this.canvasEl.nativeElement;

    // To properly handle resizing, we must save the current signature,
    // resize the canvas, and then redraw the signature.
    const data = this.signaturePad.isEmpty() 
        ? null
        : this.signaturePad.toDataURL('image/png');

    const ratio = Math.max(window.devicePixelRatio || 1, 1);
    canvas.width = canvas.offsetWidth * ratio;
    canvas.height = canvas.offsetHeight * ratio;
    canvas.getContext('2d')?.scale(ratio, ratio);
    
    // The library clears the canvas on resize. We must restore the data.
    this.signaturePad.clear();
    if (data) {
        this.signaturePad.fromDataURL(data);
    }
  }

  private emitSignature() {
    if (!this.signaturePad || this.signaturePad.isEmpty()) {
      this.signatureChange.emit('');
    } else {
      // Use PNG for transparency support
      const dataUrl = this.signaturePad.toDataURL('image/png');
      this.signatureChange.emit(dataUrl);
    }
  }

  clear() {
    if (this.signaturePad) {
      this.signaturePad.clear();
    }
    this.signatureChange.emit('');
  }
}