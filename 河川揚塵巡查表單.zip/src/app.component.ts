import { ChangeDetectionStrategy, Component, signal, WritableSignal } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MapComponent } from './map.component';
import { PreviewModalComponent } from './preview-modal.component';
import { SignaturePadComponent } from './signature-pad.component';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [ReactiveFormsModule, MapComponent, PreviewModalComponent, SignaturePadComponent],
})
export class AppComponent {
  isFetchingLocation = signal(false);
  isSubmitting = signal(false);
  showPreview = signal(false);
  previewData = signal<any>(null);
  form: WritableSignal<FormGroup>;

  constructor(
    private fb: FormBuilder
  ) {
    try {
      this.form = signal(this.fb.group({
        // Page 1
        inspectionTimeStart: [''],
        inspectionTimeEnd: [''],
        riverBasin: this.fb.group({
          daan: [false],
          dajia: [false],
          wu: [false],
        }),
        controlPointId: [''],
        inspectionType: this.fb.group({
          routine: [false],
          responseRiverDust: [false],
          responseAirQuality: [false],
          other: [false],
        }),
        coordinates: this.fb.group({
          latitude: [''],
          longitude: [''],
        }),
        onSiteMeasurements: this.fb.group({
          temperature: [''],
          humidity: [''],
          windDirection: [''],
          windSpeed: [''],
        }),
        pm10: this.fb.group({
          shalu: [''],
          taian: [''],
          xinzhuang: [''],
        }),
        weather: [''],
        climateType: this.fb.group({
          plumRain: [false],
          northeastMonsoon: [false],
          typhoon: [false],
          other: [false],
        }),
        useChemicals: ['no'],
        surroundingEvents: this.fb.group({
          openBurning: [false],
          construction: [false],
          gravelPit: [false],
          other: [false],
          otherText: [''],
        }),
        notesLastMonth: this.createPhotoControl(),
        notesThisMonth: this.createPhotoControl(),
    
        // Page 2
        riverbedObservation: this.fb.group({
          riverChannel: this.createObservationSection(),
          highWaterArea: this.createObservationSection(),
          plantingArea: this.createObservationSection(),
        }),
        inspectionDescription: [''],
        inspector: [''],
      }));
    } catch (error) {
        console.error("CRITICAL ERROR: Failed to initialize the form.", error);
        alert("應用程式表單初始化失敗，請檢查瀏覽器控制台以獲取詳細資訊。");
        throw error;
    }
  }

  createPhotoControl(): FormGroup {
    return this.fb.group({
      fileName: [''],
      fileContent: [''] // Base64 content
    });
  }

  createObservationSection(): FormGroup {
    return this.fb.group({
      notApplicable: [false],
      bareAreaOverHalfHectare: ['no'],
      noDustConcern: this.fb.group({
        option1: [false],
        option2: [false],
        option3: [false],
        option4: [false],
        option5: [false],
      }),
      dustConcern: this.fb.group({
        option1: [false],
        option2: [false],
        option3: [false],
        option4: [false],
        option5: [false],
      }),
      dustPhenomenon: ['none'],
    });
  }

  onPhotoChange(event: Event, controlPath: string) {
    const input = event.target as HTMLInputElement;
    const control = this.form().get(controlPath);

    if (input.files && input.files.length > 0 && control) {
        const file = input.files[0];
        const reader = new FileReader();
        reader.onload = () => {
            const base64Content = (reader.result as string).split(',')[1];
            control.patchValue({
                fileName: file.name,
                fileContent: base64Content
            });
        };
        reader.readAsDataURL(file);
    } else if (control) {
        control.patchValue({ fileName: '', fileContent: '' });
    }
  }

  onSignatureChange(signatureDataUrl: string) {
    this.form().get('inspector')?.setValue(signatureDataUrl);
  }

  getCurrentLocation() {
    if (navigator.geolocation) {
      this.isFetchingLocation.set(true);
      navigator.geolocation.getCurrentPosition(
        (position: GeolocationPosition) => {
          const coords = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          };
          this.form().get('coordinates')?.patchValue(coords);
          this.isFetchingLocation.set(false);
        },
        (error: GeolocationPositionError) => {
          this.isFetchingLocation.set(false);
          let errorMessage = '發生未知錯誤。';
          switch (error.code) {
            case error.PERMISSION_DENIED:
              errorMessage = '使用者拒絕了地理位置的請求。';
              break;
            case error.POSITION_UNAVAILABLE:
              errorMessage = '位置資訊無法取得。';
              break;
            case error.TIMEOUT:
              errorMessage = '取得使用者位置的請求已逾時。';
              break;
          }
          alert(`無法取得座標：${errorMessage}`);
        }
      );
    } else {
      alert('您的瀏覽器不支援地理位置定位功能。');
    }
  }

  togglePreview(state: boolean) {
    if (state) {
      const currentData = this.form().value;
      const safeData = {
        ...currentData,
        riverbedObservation: currentData.riverbedObservation || {
          riverChannel: null,
          highWaterArea: null,
          plantingArea: null
        }
      };
      this.previewData.set(safeData);
    }
    this.showPreview.set(state);
  }

  async onSubmit() {
    if (this.form().invalid) {
      alert('表單尚有未完成的欄位');
      return;
    }
    
    this.isSubmitting.set(true);
    console.log('Form Submitted. Data:', this.form().value);

    // Simulate a network request for better UX
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    alert('表單已成功提交！');
    this.form().reset();
    this.isSubmitting.set(false);
  }
}