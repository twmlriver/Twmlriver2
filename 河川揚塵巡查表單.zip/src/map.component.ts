import { Component, ElementRef, OnChanges, SimpleChanges, ViewChild, AfterViewInit, input, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import * as L from 'leaflet';

@Component({
  selector: 'app-map',
  standalone: true,
  template: `<div #mapContainer class="w-full h-64 rounded-md border bg-gray-100"></div>`,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MapComponent implements AfterViewInit, OnChanges, OnDestroy {
  latitude = input.required<number | string | null | undefined>();
  longitude = input.required<number | string | null | undefined>();
  mapType = input<'roadmap' | 'satellite' | 'nlsc-ortho'>('roadmap');

  @ViewChild('mapContainer') mapContainer!: ElementRef;
  
  private map: L.Map | null = null;
  private marker: L.Marker | null = null;
  
  // Set a default icon to prevent 404 errors for the default blue marker icon
  private defaultIcon = L.icon({
      iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
      iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
      shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
      shadowSize: [41, 41]
  });


  ngAfterViewInit() {
    // Delay initialization slightly to ensure the container has been rendered with its final size.
    setTimeout(() => this.initMap(), 0);
  }

  ngOnChanges(changes: SimpleChanges) {
    if ((changes['latitude'] || changes['longitude']) && this.map) {
      this.updateMap();
    }
  }

  ngOnDestroy() {
    if (this.map) {
      this.map.remove();
      this.map = null;
    }
  }

  private initMap(): void {
    if (this.map || !this.mapContainer) {
        return;
    }

    const lat = Number(this.latitude());
    const lng = Number(this.longitude());

    if (isNaN(lat) || isNaN(lng)) return;
    
    const coordinates: L.LatLngTuple = [lat, lng];

    this.map = L.map(this.mapContainer.nativeElement, {
        center: coordinates,
        zoom: 15,
        attributionControl: true, // Enable attribution
    });

    let tileLayer: L.TileLayer;
    if (this.mapType() === 'nlsc-ortho') {
        // NLSC WMTS URL for orthophotos (正射影像圖)
        tileLayer = L.tileLayer('https://wmts.nlsc.gov.tw/wmts/PHOTO2/default/GoogleMapsCompatible/{z}/{y}/{x}.jpg', {
            maxZoom: 20,
            minZoom: 8,
            attribution: '© <a href="https://www.nlsc.gov.tw/" target="_blank">國土測繪中心</a>'
        });
    } else {
        // Default to OpenStreetMap for 'roadmap' or any other value
        tileLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '© <a href="http://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a>'
        });
    }
    
    tileLayer.addTo(this.map);

    this.marker = L.marker(coordinates, { icon: this.defaultIcon }).addTo(this.map);
  }

  private updateMap(): void {
    if (!this.map || !this.marker) {
      return;
    }
    
    const lat = Number(this.latitude());
    const lng = Number(this.longitude());

    if (isNaN(lat) || isNaN(lng)) return;

    const coordinates: L.LatLngTuple = [lat, lng];
    this.map.setView(coordinates, this.map.getZoom());
    this.marker.setLatLng(coordinates);
  }
}
