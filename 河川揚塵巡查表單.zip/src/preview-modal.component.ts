import { Component, input, output, ChangeDetectionStrategy } from '@angular/core';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-preview-modal',
  standalone: true,
  imports: [DatePipe],
  template: `
    <div class="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50" (click)="close()">
      <div class="bg-white rounded-lg shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col" (click)="$event.stopPropagation()">
        
        <header class="flex items-center justify-between p-4 border-b">
          <h2 class="text-2xl font-bold text-gray-800">表單預覽</h2>
          <button (click)="close()" class="text-gray-500 hover:text-gray-800 text-2xl">&times;</button>
        </header>

        <main class="p-6 overflow-y-auto space-y-6 text-sm">
          <!-- Basic Info -->
          <section>
            <h3 class="font-semibold text-lg text-blue-700 border-b pb-2 mb-3">基本資料</h3>
            <div class="grid grid-cols-2 gap-x-4 gap-y-2">
              <div class="font-bold text-gray-600">巡查時間:</div>
              <div>
                @if(formData.inspectionTimeStart) {
                  {{ formData.inspectionTimeStart | date:'yyyy/MM/dd HH:mm' }}
                } @else {
                  未設定
                }
                至 
                @if(formData.inspectionTimeEnd) {
                  {{ formData.inspectionTimeEnd | date:'yyyy/MM/dd HH:mm' }}
                } @else {
                  未設定
                }
              </div>

              <div class="font-bold text-gray-600">流域名稱:</div>
              <div>
                @if(formData.riverBasin?.daan) { <span>大安溪</span> }
                @if(formData.riverBasin?.dajia) { <span class="ml-2">大甲溪</span> }
                @if(formData.riverBasin?.wu) { <span class="ml-2">烏溪</span> }
              </div>

              <div class="font-bold text-gray-600">管制點編號:</div>
              <div>{{ formData.controlPointId || '未填寫' }}</div>
              
              <div class="font-bold text-gray-600">巡查類別:</div>
              <div>
                @if(formData.inspectionType?.routine) { <span>例行性巡查</span> }
                @if(formData.inspectionType?.responseRiverDust) { <span class="ml-2">應變(河川揚塵)</span> }
                @if(formData.inspectionType?.responseAirQuality) { <span class="ml-2">應變(空品不良)</span> }
                @if(formData.inspectionType?.other) { <span class="ml-2">其他</span> }
              </div>
            </div>
          </section>

          <!-- On-site Data -->
          <section>
            <h3 class="font-semibold text-lg text-blue-700 border-b pb-2 mb-3">現場量測與環境資料</h3>
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-2">
              <div class="font-bold text-gray-600">緯度(X):</div>
              <div>{{ formData.coordinates?.latitude || '未提供' }}</div>
              <div class="font-bold text-gray-600">經度(Y):</div>
              <div>{{ formData.coordinates?.longitude || '未提供' }}</div>
              
              <div class="font-bold text-gray-600">溫度 (°C):</div>
              <div>{{ formData.onSiteMeasurements?.temperature || '未量測' }}</div>
              <div class="font-bold text-gray-600">濕度 (%):</div>
              <div>{{ formData.onSiteMeasurements?.humidity || '未量測' }}</div>
              <div class="font-bold text-gray-600">風向 (°):</div>
              <div>{{ formData.onSiteMeasurements?.windDirection || '未量測' }}</div>
              <div class="font-bold text-gray-600">風速 (m/sec):</div>
              <div>{{ formData.onSiteMeasurements?.windSpeed || '未量測' }}</div>

              <div class="font-bold text-gray-600">PM10 沙鹿:</div>
              <div>{{ formData.pm10?.shalu || '未提供' }}</div>
              <div class="font-bold text-gray-600">PM10 泰安:</div>
              <div>{{ formData.pm10?.taian || '未提供' }}</div>
              <div class="font-bold text-gray-600">PM10 新庄:</div>
              <div>{{ formData.pm10?.xinzhuang || '未提供' }}</div>

              <div class="font-bold text-gray-600">天氣:</div>
              <div>{{ formData.weather || '未選擇' }}</div>
              
              <div class="font-bold text-gray-600">氣候型態:</div>
              <div>
                @if(formData.climateType?.plumRain) { <span>梅雨季</span> }
                @if(formData.climateType?.northeastMonsoon) { <span class="ml-2">東北季風</span> }
                @if(formData.climateType?.typhoon) { <span class="ml-2">颱風</span> }
                @if(formData.climateType?.other) { <span class="ml-2">其他</span> }
              </div>
              
              <div class="font-bold text-gray-600">使用化學藥劑:</div>
              <div>{{ formData.useChemicals === 'yes' ? '是' : '否' }}</div>
            </div>
          </section>

          <!-- Surrounding Events & Bare Land -->
          <section>
            <h3 class="font-semibold text-lg text-blue-700 border-b pb-2 mb-3">周邊事件與裸露地</h3>
             <div class="grid grid-cols-2 gap-x-4 gap-y-2">
                <div class="font-bold text-gray-600">周邊事件:</div>
                <div>
                  @if(formData.surroundingEvents?.openBurning) { <span>露天燃燒</span> }
                  @if(formData.surroundingEvents?.construction) { <span class="ml-2">營建或疏濬工程</span> }
                  @if(formData.surroundingEvents?.gravelPit) { <span class="ml-2">砂石場</span> }
                  @if(formData.surroundingEvents?.other) {
                    <span class="ml-2">其他: {{ formData.surroundingEvents.otherText || '未填寫' }}</span>
                  }
                </div>

                <div class="font-bold text-gray-600 col-span-2 mt-2">照片</div>
                <div class="font-bold text-gray-500">上月照片:</div>
                <div>{{ formData.notesLastMonth?.fileName || '未上傳' }}</div>
                <div class="font-bold text-gray-500">本月照片:</div>
                <div>{{ formData.notesThisMonth?.fileName || '未上傳' }}</div>
             </div>
          </section>

          <!-- Riverbed Observation -->
          <section>
             <h3 class="font-semibold text-lg text-blue-700 border-b pb-2 mb-3">河床觀測結果</h3>
             <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
               @if (formData.riverbedObservation) {
                @for(area of ['riverChannel', 'highWaterArea', 'plantingArea']; track area) {
                  @if(formData.riverbedObservation[area]; as obs) {
                    <div class="bg-gray-50 p-3 rounded-md space-y-2">
                      <h4 class="font-bold text-center mb-2">
                        @if(area === 'riverChannel') { 河道 }
                        @if(area === 'highWaterArea') { 高灘地 }
                        @if(area === 'plantingArea') { 種植地 }
                      </h4>
                      <dl class="space-y-1">
                        <dt class="font-semibold">無本項:</dt>
                        <dd class="pl-2">{{ obs.notApplicable ? '是' : '否' }}</dd>

                        <dt class="font-semibold">裸露面積 > 0.5ha:</dt>
                        <dd class="pl-2">{{ obs.bareAreaOverHalfHectare === 'yes' ? '是' : '否' }}</dd>
                        
                        <dt class="font-semibold">無揚塵之虞:</dt>
                        <dd class="pl-2 text-blue-800">
                           @switch (area) {
                              @case ('riverChannel') {
                                @if(obs.noDustConcern?.option1) { <div>植生覆蓋</div> }
                                @if(obs.noDustConcern?.option2) { <div>水覆蓋</div> }
                                @if(obs.noDustConcern?.option3) { <div>砂礫混和類似級配作用</div> }
                                @if(obs.noDustConcern?.option4) { <div>河床濕潤或結殼</div> }
                                @if(obs.noDustConcern?.option5) { <div>其他</div> }
                                @if (!obs.noDustConcern?.option1 && !obs.noDustConcern?.option2 && !obs.noDustConcern?.option3 && !obs.noDustConcern?.option4 && !obs.noDustConcern?.option5) {
                                   <span>無</span>
                                }
                              }
                              @case ('highWaterArea') {
                                @if(obs.noDustConcern?.option1) { <div>自然植生覆蓋</div> }
                                @if(obs.noDustConcern?.option2) { <div>砂礫混和類似級配作用</div> }
                                @if(obs.noDustConcern?.option3) { <div>河床濕潤或結殼</div> }
                                @if(obs.noDustConcern?.option4) { <div>其他</div> }
                                @if (!obs.noDustConcern?.option1 && !obs.noDustConcern?.option2 && !obs.noDustConcern?.option3 && !obs.noDustConcern?.option4) {
                                   <span>無</span>
                                }
                              }
                              @case ('plantingArea') {
                                @if(obs.noDustConcern?.option1) { <div>作物覆蓋</div> }
                                @if(obs.noDustConcern?.option2) { <div>河床濕潤或結殼</div> }
                                @if(obs.noDustConcern?.option3) { <div>揚塵防制措施</div> }
                                @if(obs.noDustConcern?.option4) { <div>其他</div> }
                                @if (!obs.noDustConcern?.option1 && !obs.noDustConcern?.option2 && !obs.noDustConcern?.option3 && !obs.noDustConcern?.option4) {
                                   <span>無</span>
                                }
                              }
                           }
                        </dd>

                        <dt class="font-semibold">有揚塵之虞:</dt>
                        <dd class="pl-2 text-red-800">
                           @switch (area) {
                              @case ('riverChannel') {
                                @if(obs.dustConcern?.option1) { <div>大面積淤砂</div> }
                                @if(obs.dustConcern?.option2) { <div>多處零星淤沙區</div> }
                                @if(obs.dustConcern?.option3) { <div>河床乾燥</div> }
                                @if(obs.dustConcern?.option4) { <div>其他</div> }
                                @if (!obs.dustConcern?.option1 && !obs.dustConcern?.option2 && !obs.dustConcern?.option3 && !obs.dustConcern?.option4) {
                                   <span>無</span>
                                }
                              }
                              @case ('highWaterArea') {
                                @if(obs.dustConcern?.option1) { <div>大面積淤沙</div> }
                                @if(obs.dustConcern?.option2) { <div>多處零星淤沙區</div> }
                                @if(obs.dustConcern?.option3) { <div>使用除草劑</div> }
                                @if(obs.dustConcern?.option4) { <div>其他</div> }
                                @if (!obs.dustConcern?.option1 && !obs.dustConcern?.option2 && !obs.dustConcern?.option3 && !obs.dustConcern?.option4) {
                                   <span>無</span>
                                }
                              }
                              @case ('plantingArea') {
                                @if(obs.dustConcern?.option1) { <div>大面積淤沙</div> }
                                @if(obs.dustConcern?.option2) { <div>多處零星淤沙區</div> }
                                @if(obs.dustConcern?.option3) { <div>使用除草劑</div> }
                                @if(obs.dustConcern?.option4) { <div>翻土整地</div> }
                                @if(obs.dustConcern?.option5) { <div>其他</div> }
                                @if (!obs.dustConcern?.option1 && !obs.dustConcern?.option2 && !obs.dustConcern?.option3 && !obs.dustConcern?.option4 && !obs.dustConcern?.option5) {
                                   <span>無</span>
                                }
                              }
                           }
                        </dd>
                        
                        <dt class="font-semibold">揚塵現象:</dt>
                        <dd class="pl-2">
                           @switch (obs.dustPhenomenon) {
                              @case ('none') { <span>無</span> }
                              @case ('escaped') { <span>已影響至堤防內</span> }
                              @case ('contained') {
                                @if (area === 'riverChannel') {
                                  <span>集中於河道未飄越堤防</span>
                                } @else {
                                  <span>集中於本區未飄越堤防</span>
                                }
                              }
                              @default { <span>{{ obs.dustPhenomenon || '未選擇' }}</span> }
                           }
                        </dd>
                      </dl>
                    </div>
                  }
                }
               }
             </div>
          </section>

          <!-- Final Section -->
           <section>
            <h3 class="font-semibold text-lg text-blue-700 border-b pb-2 mb-3">查核說明與巡查員</h3>
            <div class="grid grid-cols-1 gap-2">
                <div class="font-bold text-gray-600">查核說明:</div>
                <div class="p-2 border rounded bg-gray-50 whitespace-pre-wrap">{{ formData.inspectionDescription || '無' }}</div>
                <div class="font-bold text-gray-600 mt-2">巡查員簽名:</div>
                <div>
                  @if (formData.inspector) {
                    <img [src]="formData.inspector" alt="Inspector Signature" class="border rounded-md bg-gray-50 max-w-[200px] h-auto"/>
                  } @else {
                    <span>未簽名</span>
                  }
                </div>
            </div>
           </section>

        </main>

      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PreviewModalComponent {
  formData = input.required<any>();
  closeModal = output<void>();

  close() {
    this.closeModal.emit();
  }
}